package org.shathursan.utils;

public class ApiEndpoints {
  public static final String GENERATE = "/generate";

}
