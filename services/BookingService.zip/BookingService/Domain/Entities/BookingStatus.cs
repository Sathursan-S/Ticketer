﻿namespace BookingService.Domain.Entities;

public enum BookingStatus
{
    PENDING,
    COMPLETED,
    REJECTED,
    CANCELED
}